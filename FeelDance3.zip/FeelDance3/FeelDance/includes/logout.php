<?php
session_start();
session_unset();
session_destroy();

// Absolute path redirection (adjust to your actual path)
header('Location: ../admin/index.php');
exit();
?>
