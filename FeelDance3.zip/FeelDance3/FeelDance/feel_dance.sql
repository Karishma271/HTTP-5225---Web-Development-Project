-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2024 at 11:56 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `feel_dance`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `first_name`, `last_name`, `password`) VALUES
(1, 'feel', 'feeldance@example.com', 'Karishma', 'Patel', '88698b6a4506539f5c5588da47a10171'),
(2, 'feel', 'feeldance@example.com', 'Karishma', 'Patel', '88698b6a4506539f5c5588da47a10171');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(100) NOT NULL,
  `class_time` datetime NOT NULL,
  `video_id` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_id`, `class_name`, `class_time`, `video_id`, `deleted_at`) VALUES
(1, 'Urban', '2024-08-01 18:00:00', NULL, '2024-08-02 00:17:29'),
(2, 'Bharatanatyam', '2024-08-02 17:00:00', NULL, NULL),
(3, 'Hip Hop', '2024-08-01 18:00:00', 'yc05MGEzdGs', NULL),
(4, 'Bharatanatyam', '2024-08-02 17:00:00', NULL, NULL),
(5, 'Krump', '2024-08-17 10:10:00', NULL, NULL),
(6, 'Bollywood', '2024-08-25 11:20:00', 'e5fWuJYZr5Y', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `member_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('student','instructor') NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `name`, `email`, `role`, `image`, `deleted_at`, `class_id`) VALUES
(1, 'Abhi Kori', 'abhi@example.com', 'instructor', 'instructor2.jpeg', NULL, 1),
(2, 'Bhavin Desai', 'bhavin.desai@example.com', 'student', NULL, '2024-08-02 00:05:05', 2),
(3, 'Chetan Mehta', 'chetan.mehta@ex.com', 'student', NULL, '2024-08-02 16:33:41', 3),
(4, 'Karan Bhatt', 'karan.bhatt@example.com', 'instructor', 'karan_bhatt.jpg', '2024-08-02 16:34:20', NULL),
(5, 'Lata Joshi', 'lata.joshi@example.com', 'instructor', 'lata_joshi.jpg', NULL, 5),
(6, 'Karishma Patel', 'kp@gmail.com', 'instructor', 'instructor1.jpeg', NULL, NULL),
(7, 'zankhana', 'zankhu21@example.com', 'student', '1.jpg', '2024-08-02 00:54:07', NULL),
(8, 'zankhana', 'zankhu21@example.com', 'student', '1.jpg', '2024-08-02 00:54:11', NULL),
(9, 'zankhana', 'zankhu21@example.com', 'student', '1.jpg', NULL, NULL),
(10, 'vilas more', 'vilas@gmail.com', 'instructor', 'instructor3.jpeg', NULL, 3),
(11, 'vilas more', 'vilas@gmail.com', 'instructor', 'instructor3.jpeg', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`class_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`member_id`),
  ADD KEY `fk_class` (`class_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `members`
--
ALTER TABLE `members`
  ADD CONSTRAINT `fk_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
