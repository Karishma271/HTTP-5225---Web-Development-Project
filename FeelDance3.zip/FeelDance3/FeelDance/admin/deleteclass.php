<?php
include '../reusable/connection.php';
include '../includes/functions.php';

// Check if the 'class_id' parameter is present in the URL
if (isset($_GET['class_id'])) {
    $class_id = mysqli_real_escape_string($conn, $_GET['class_id']);

    // SQL query to soft-delete the class
    $sql = "UPDATE classes 
            SET deleted_at = NOW() 
            WHERE class_id = '$class_id'";

    if ($conn->query($sql) === TRUE) {
        set_message("Class deleted successfully", "success");
    } else {
        // Debugging: Output error message
        set_message("Error: " . $conn->error, "danger");
    }
} else {
    set_message("Invalid request", "danger");
}

// Redirect to the classes page
header('Location: classes.php'); // Ensure this is the correct page
exit();
?>
