<?php
include '../reusable/connection.php';

if (isset($_GET['member_id'])) {
    $member_id = $_GET['member_id'];
    
    $delete_query = "UPDATE members SET deleted_at = NOW() WHERE member_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $member_id);

    if ($stmt->execute()) {
        echo "<p>Member soft deleted successfully.</p>";
    } else {
        echo "<p>Error soft deleting member.</p>";
    }
}
header("Location: manageallocation.php");
?>
