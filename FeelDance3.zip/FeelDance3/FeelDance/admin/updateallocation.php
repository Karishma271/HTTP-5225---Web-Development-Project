<?php
include '../reusable/connection.php';
include '../includes/functions.php';

// Check if the 'member_id' parameter is present in the URL
if (isset($_GET['member_id'])) {
    $member_id = mysqli_real_escape_string($conn, $_GET['member_id']);

    // If the form is submitted
    if (isset($_POST['updateMember'])) {
        $member_name = mysqli_real_escape_string($conn, $_POST['member_name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $role = mysqli_real_escape_string($conn, $_POST['role']);

        $sql = "UPDATE members 
                SET name='$member_name', email='$email', role='$role' 
                WHERE member_id='$member_id'";
        if ($conn->query($sql) === TRUE) {
            set_message("Member updated successfully", "success");
        } else {
            set_message("Error: " . $sql . "<br>" . $conn->error, "danger");
        }
        header('Location: manageallocation.php');
        exit();
    } else {
        // Fetch the member details from the database
        $sql = "SELECT * FROM members WHERE member_id='$member_id' AND deleted_at IS NULL";
        $result = $conn->query($sql);
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
        } else {
            set_message("Member not found", "danger");
            header('Location: manageallocation.php');
            exit();
        }
    }
} else {
    set_message("Invalid request", "danger");
    header('Location: manageallocation.php');
    exit();
}
?>

<?php include '../reusable/header-admin.php'; ?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="../reusable/css/styles.css">

<div class="container mt-5">
    <h1 class="text-center">Edit Member</h1>
    <?php get_message(); ?>
    <form method="post" class="mt-4">
        <input type="hidden" name="updateMember" value="1">
        <div class="form-group">
            <label for="member_name">Member Name</label>
            <input type="text" class="form-control" id="member_name" name="member_name" value="<?php echo htmlspecialchars($row['name']); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required>
        </div>
        <div class="form-group">
            <label for="role">Role</label>
            <input type="text" class="form-control" id="role" name="role" value="<?php echo htmlspecialchars($row['role']); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Member</button>
    </form>
</div>

<?php include '../reusable/footer-admin.php'; ?>