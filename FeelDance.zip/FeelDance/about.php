<?php
include('../includes/header.php');
?>

<h2>About Us</h2>
<p>Learn more about our dance studio and our mission.</p>

<?php
include('../includes/footer.php');
?>
